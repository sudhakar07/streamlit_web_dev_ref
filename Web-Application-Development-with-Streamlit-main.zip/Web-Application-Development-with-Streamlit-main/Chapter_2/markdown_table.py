import streamlit as st

st.markdown(
'''
Name | Score 1 | Score 2
------------ | ------------- | -------------
Jessica | 77 | 76
John | 56 | 97
Alex | 87 | 82
'''
)
