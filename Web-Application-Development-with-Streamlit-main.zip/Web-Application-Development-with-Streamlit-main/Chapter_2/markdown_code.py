import streamlit as st

st.markdown(
'''
```
def hello_world():
    print('Hello world')
```
'''
)
st.markdown(
'''
```python
def hello_world():
    print('Hello world')
```
'''
)
