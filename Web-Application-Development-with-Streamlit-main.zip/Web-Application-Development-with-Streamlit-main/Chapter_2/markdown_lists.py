import streamlit as st

st.markdown(
'''
- Hello world
- Hello world
- Hello world
'''
)
st.markdown(
'''
1. Hello world
2. Hello world
3. Hello world
'''
)
st.markdown(
'''
- [x]  Hello world
- [ ]  Hello world
'''
)
