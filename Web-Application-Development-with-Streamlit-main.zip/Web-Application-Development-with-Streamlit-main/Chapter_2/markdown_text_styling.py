import streamlit as st

st.markdown('**Hello world**')
st.markdown('_Hello world_')
st.markdown('~~Hello world~~')
