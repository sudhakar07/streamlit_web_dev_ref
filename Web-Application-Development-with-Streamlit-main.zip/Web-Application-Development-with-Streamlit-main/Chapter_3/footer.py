st.sidebar.markdown(
    f'''<div class="markdown-text-container stText" style="width: 698px;">
    <footer><p></p></footer><div style="font-size: 12px;">Hello world v 0.1</div>
    <div style="font-size: 12px;">Hello world LLC.</div></div>''',
    unsafe_allow_html=True)
