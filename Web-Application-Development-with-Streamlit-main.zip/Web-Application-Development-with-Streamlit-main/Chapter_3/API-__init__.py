from .API import API as _API

api_instance = _API()
