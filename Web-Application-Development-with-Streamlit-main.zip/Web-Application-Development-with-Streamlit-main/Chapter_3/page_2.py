import streamlit as st

def func_page_2():
    st.title('Page 2')
