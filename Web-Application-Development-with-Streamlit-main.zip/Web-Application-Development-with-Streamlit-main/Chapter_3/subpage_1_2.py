import streamlit as st

def func_subpage_1_2():
    st.title('Subpage 1.2')
