import streamlit as st

def func_page_1():
    st.title('Page 1')
