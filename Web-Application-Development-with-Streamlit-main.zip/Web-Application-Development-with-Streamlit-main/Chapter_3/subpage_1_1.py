import streamlit as st

def func_subpage_1_1():
    st.title('Subpage 1.1')
